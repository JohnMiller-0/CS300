	//============================================================================
	// Name        : ProjectTwo.cpp
	// Author      : John Miller
	// Version     : 1.0
	// Description : Project Two Binary Search Tree
	//============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>


using namespace std;

	//============================================================================
	// Global definitions visible to all methods and classes
	//============================================================================


	// define a structure to hold course information

	struct Course
	{
		string courseId;
		string title;
		vector<string> prereqList;

		Course() {}

		Course(vector<string>& tList)
		{
			int i;
			courseId = tList.at(0);
			title = tList.at(1);
			for (i = 2; i < tList.size(); ++i)
			{
				prereqList.push_back(tList.at(i));
			}
		}

	};

	// Internal structure for tree node
	struct Node
	{
		Course course;
		Node* left;
		Node* right;

		Node()
		{
			left = nullptr;
			right = nullptr;
		}

		Node(Course aCourse)
		{
			left = nullptr;
			right = nullptr;
			course = aCourse;
		}
	};

	//============================================================================
	// Binary Search Tree class definition
	//============================================================================

	/**
	 * Define a class containing data members and methods to
	 * implement a binary search tree
	 */
	class BinarySearchTree {

	private:
		Node* root;

		void addNode(Node* node, Course aCourse);
		void inOrder(Node* node);
		Node* removeNode(Node* node, string courseId);
		int prereqChecker(Node* node);

	public:
		BinarySearchTree();
		int readFile(string fileName);
		virtual ~BinarySearchTree();
		void InOrder();
		void Insert(Course course);
		void Remove(string courseId);
		Course Search(string courseId);
	};

	/**
	 * Default constructor
	 */
	BinarySearchTree::BinarySearchTree() {
		root = nullptr;

	}

	/**
	 * Destructor
	 */
	BinarySearchTree::~BinarySearchTree() {
		while (root != nullptr)
		{
			root = this->removeNode(root, root->course.courseId);
		}
	}

	int BinarySearchTree::readFile(string fileName)
	{
		ifstream inFile(fileName);

		if (!inFile.is_open()) // Check to see if file is successfully opened.
		{
			cerr << "Error opening file" << endl;
			return 1;
		}

		string line;
		while (getline(inFile, line)) // Continue to the end of the file
		{
			stringstream ss(line); // Create a string stream object
			string token;
			vector<string> tokens;

			// Parse the line into tokens
			while (getline(ss, token, ','))
			{
				tokens.push_back(token);
			}

			// Check to see the line contains at least a courseId and title.
			if (tokens.size() < 2)
			{
				cerr << "Error in file format: " << line << endl;
				inFile.close();
				return 1;
			}
			else
			{
				// Create a new course object
				Course course = Course(tokens);
				// Insert the course into the tree.
				this->Insert(course);
			}
		}

		inFile.close();  // Ensure the file is closed after processing all lines
		
		return this->prereqChecker(root);
	}

	int BinarySearchTree::prereqChecker(Node* node)
	{
		// Check to see if node is null
		if (node != nullptr)
		{
			// Find left most child
			prereqChecker(node->left);
			// Check to ensure prereqs exist
			if (!node->course.prereqList.at(0).empty())
			{
				for (int i = 0; i < node->course.prereqList.size(); ++i)
				{
					// Use search to return matching course
					Course course = Search(node->course.prereqList.at(i));
					// CHeck to see search was successful
					if (!course.courseId.empty())
					{
						continue;
					}
					else
					{
						// Output erroneous prerequisite and course.
						cout << "Invalid prerequisite " << node->course.prereqList.at(i) << " found for course " << node->course.courseId << endl;
					}
				}
			}
			// Check right child
			prereqChecker(node->right);
		}

		return 0;
	}
	/**
	 * Traverse the tree in order
	 */
	void BinarySearchTree::InOrder() {
		this->inOrder(root);
	}

	/**
	 * Insert a course
	 */
	void BinarySearchTree::Insert(Course course) {
		if (root == nullptr)
		{
			// if root is null new node is root
			root = new Node(course);
		}
		else
		{
			// Otherwise add node to tree
			this->addNode(root, course);
		}
	}

	/**
	 * Remove a course
	 */
	void BinarySearchTree::Remove(string courseId) {
		// Called and assigned to the root so the tree is auto-ordered
		root = this->removeNode(root, courseId);

	}

	/**
	 * Search for a course
	 */
	Course BinarySearchTree::Search(string courseId) {
		Course course;

		Node* current = root;

		while (current != nullptr)
		{
			// If course matches
			if (courseId == current->course.courseId)
			{
				course = current->course;
				return course;
			}
			// If course is less than current
			else if (courseId < current->course.courseId)
			{
				current = current->left;
			}
			// course is more than current
			else
			{
				current = current->right;
			}
		}


		return course;


	}

	/**
	 * Add a course to some node (recursive)
	 *
	 * @param node Current node in tree
	 * @param course course to be added
	 */
	void BinarySearchTree::addNode(Node * node, Course course) {
		// If courseId is less than current courseId at current node
		if (course.courseId.compare(node->course.courseId) < 0)
		{
			if (node->left == nullptr)
			{
				// No left child found new node is assigned as left child
				node->left = new Node(course);
			}
			else
			{
				// Recurse down the left child
				addNode(node->left, course);
			}
		}
		else
		{
			if (node->right == nullptr)
			{
				// No right child found new node is assigned as right child
				node->right = new Node(course);
			}
			else
			{
				// Recurse down the right child
				addNode(node->right, course);
			}
		}
	}

	void BinarySearchTree::inOrder(Node* node) {

		if (node != nullptr)
		{
			// Find left most child
			inOrder(node->left);

			// Output course Info
			int i;
			cout << node->course.courseId << " | " << node->course.title << " | " << "Prerequisites: ";
			
			// Iterate over prerequisites
			for (i = 0; i < node->course.prereqList.size(); ++i)
			{
				// Output "N/A" if there is no prerequisites
				if (node->course.prereqList.at(0).empty())
				{
					cout << "N/A";
				}

				cout << node->course.prereqList.at(i);
				if (i == (node->course.prereqList.size() - 1))
				{
					// End with a newline
					cout << endl;
				}
				else
				{
					// Seperate prereqs by a comma
					cout << ", ";
				}

			}

			// Find first right child
			inOrder(node->right);
		}
	}
	/**
	 * Remove a course from some node (recursive)
	 */
	Node* BinarySearchTree::removeNode(Node * node, string courseId) {

		// If no node found return
		if (node == nullptr)
		{
			return node;
		}

		// If courseId is less than current course move to the left child
		if (courseId.compare(node->course.courseId) < 0)
		{
			node->left = removeNode(node->left, courseId);
		}
		// If courseId is more than current course move to the right child
		else if (courseId.compare(node->course.courseId) > 0)
		{
			node->right = removeNode(node->right, courseId);
		}
		// If match is found
		else if (courseId.compare(node->course.courseId) == 0)
		{
			// Two childern nodes
			if ((node->right != nullptr) && (node->left != nullptr))
			{
				// Find the successor of the right child
				Node* temp = node->right;
				while (temp->left != nullptr)
				{
					temp = temp->left;
				}

				// Successor takes current nodes place
				node->course = temp->course;
				// Remove orignal successor node
				node->right = removeNode(node->right, courseId);
			}
			// One child
			else if ((node->right != nullptr) || (node->left != nullptr))
			{
				// Child is to the right
				if (node->right != nullptr)
				{
					node = node->right;
				}
				// Child is to the left
				else
				{
					node = node->left;
				}
			}
			// No Childern nodes
			else
			{
				delete node; // Delete node
				return nullptr; // Return node as a null pointer
			}

		}
		return node;
	}

	/**
	 * The one and only main() method
	 */

	void displayMenu()
	{
		cout << "[1] Load Data Fle\n";
		cout << "[2] Display Alphanumerically\n";
		cout << "[3] Search by Course ID\n";
		cout << "[9] Quit Program\n";
	}

	// Used to output course information.
	void displayCourse(Course course)
	{
		int i;
		cout << course.courseId << " | " << course.title << " | Prerequisites: ";

		for (i = 0; i < course.prereqList.size(); ++i)
		{
			if (course.prereqList.at(0).empty())
			{
				cout << "N/A";
			}

			cout << course.prereqList.at(i);

			if (i == (course.prereqList.size() - 1))
			{
				cout << endl;
			}
			else
			{
				cout << ", ";
			}
		}
	}

	int main() {

		// Define a binary search tree to hold all courses
		BinarySearchTree* bst = new BinarySearchTree();
		// Holds filename for input
		string fileName = "CS 300 ABCU_Advising_Program_Input.csv";
		// Variable for main loop
		bool runProgram = true;
		// Variables for file reading
		int fileReadIndicator;
		int errorReading = 1;
		// Variable to hold user selecrion
		char userInput;
		// For course search
		string courseId;
		Course course;

		while (runProgram)
		{
			displayMenu();

			cin >> userInput;

			switch (userInput) 
			{
				// Load data file
			case '1':
				fileReadIndicator = bst->readFile(fileName);
				if (fileReadIndicator == 0)
				{
					cout << "File successfully read" << endl;
				}
				else if (fileReadIndicator == errorReading)
				{
					cout << "Error Reading file" << endl;
					runProgram = false;
					return errorReading;
				}
				break;

				//Output Alphanumerically
			case '2':
				bst->InOrder();
				break;
			
				// Search by courseId
			case '3':
				cout << "Enter Course Id\n";
				cin >> courseId;
				course = bst->Search(courseId);
				if (!course.courseId.empty())
				{
					displayCourse(course);
				}
				else
				{
					cout << "No course with ID: " << courseId << " exists." << endl;
				}
				break;
			
				// Quit Program
			case '9':
				runProgram = false;
				cout << "Quitting Program..." << endl;
				break;

				// A catch for invalid inputs.
			default:
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				cout << "Invalid input \"" << userInput << "\" please enter 1, 2, 3, or 9\n";
				break;
			}
		}

		return 0;

	}